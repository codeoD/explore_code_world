import axios from './axios.config'
import api from './api'
// axios 的相关配置

// axios.defaults.baseURL = 'http://localhost:7000'

export { axios, api }
