import axios from './axios.config.js'

let api = {
  apiTest () {
    axios.get('')
  }
}
export { api }
