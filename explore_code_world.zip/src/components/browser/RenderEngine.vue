<template>
  <div>
    <h3 class="mt-4 mb-4">Render Engine</h3>
    <div>
      浏览器厂商前缀：
      <br>
      Chrome、新版Opera、Safari：-webkit-
      <br>
      Firefox：-moz-
      <br>
      IE、Edge：-ms-
    </div>
  </div>
</template>
<script>
export default {
  name: 'RenderEngine'
}
</script>
