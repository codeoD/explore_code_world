<template>
  <div>
    <header>欢迎登录！</header>
    <router-view />
    <footer>这里是底部</footer>
  </div>
</template>
<script>
export default {
  name: 'SignIndex'
}
</script>
