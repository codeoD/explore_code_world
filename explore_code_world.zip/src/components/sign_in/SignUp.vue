<template>
  <div>
    up
  </div>
</template>
<script>
export default {
  name: 'SignUp'
}
</script>
