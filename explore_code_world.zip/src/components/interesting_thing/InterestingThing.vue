<template>
  <div>
    interesting thing~
  </div>
</template>
<script>
export default {
  name: 'InterestingThing'
}
</script>
