export default {
  logined: false
}
